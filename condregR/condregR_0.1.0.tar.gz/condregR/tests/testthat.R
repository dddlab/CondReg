library(testthat)
library(condregR)

test_check("condregR") 